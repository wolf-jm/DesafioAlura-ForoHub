package ForoHub.ByWolf;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ByWolfApplicationTests {

	@Test
	void contextLoads() {
	}

}
